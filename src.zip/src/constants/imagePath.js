export default  ImagePath = 

{

    addImage: {uri:'https://seniuk.com/wp-content/uploads/2018/11/30-512.png'},
    delete: {uri:"https://image.shutterstock.com/image-vector/delete-icongarbage-trash-can-rubbish-260nw-1211550652.jpg"}

}