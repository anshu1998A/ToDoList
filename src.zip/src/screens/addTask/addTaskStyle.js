import {StyleSheet} from 'react-native';

export default homeStyle = StyleSheet.create ({
    homeView:{
        // backgroundColor:'red',
        flex:1,
        justifyContent:'center',
        alignItems:'center'
    },
    addDataText:{
        color:'black',
        fontSize:20,
    },
    addButton:{
        
    }
})