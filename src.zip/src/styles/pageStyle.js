import {  StyleSheet } from 'react-native'
  
  export default  commonStyles = StyleSheet.create ({

    errorText:{
        
          textAlign: 'center',
          color: 'red'
        },
    
  })