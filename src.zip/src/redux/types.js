export default {
    LOGIN: 'login',
    LOGOUT: 'LogOut',
    USER_DATA: 'datainput',
    DELETE_DATA: 'deletedata',
    EDIT_DATA: 'editdata',
}