import types from "../types";
export const logIN = () => {
    return {
        type: types.LOGIN
    }
}
export const Logout = () => {
    return {
        type: types.LOGOUT
    }
}
