import * as auth from './auth'
import * as details from './addDetails'
export default {
    ...auth,
    ...details,
};