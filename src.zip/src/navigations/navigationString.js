export default {
    LOGIN : 'logIn',
    HOME : 'Home',
    ADD_DETAILS: 'AddTask',
    SUBMIT : 'submit',
}